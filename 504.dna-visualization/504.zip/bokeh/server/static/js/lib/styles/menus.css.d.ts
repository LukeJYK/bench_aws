export const menu_icon: string
export const horizontal: string
export const vertical: string
export const divider: string
export const active: string
export default ""
