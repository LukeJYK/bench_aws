export const Canvas: string
export default ""
