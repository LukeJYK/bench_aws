export const input: string
export const input_container: string
export const input_prefix: string
export const input_suffix: string
export const input_group: string
export const inline: string
export const spin_wrapper: string
export const spin_btn: string
export const spin_btn_up: string
export const spin_btn_down: string
export const description: string
export const icon: string
export const opaque: string
export default ""
