export const above: string
export const below: string
export const left: string
export const right: string
export const header: string
export const tab: string
export const active: string
export const close: string
export const disabled: string
export default ""
