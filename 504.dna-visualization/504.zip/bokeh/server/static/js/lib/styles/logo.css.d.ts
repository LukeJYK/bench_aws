export const logo: string
export const grey: string
export const logo_small: string
export default ""
