export const inner: string
export const hidden: string
export const logo: string
export const above: string
export const below: string
export const left: string
export const right: string
export const divider: string
export const tool_overflow: string
export const horizontal: string
export const vertical: string
export default ""
