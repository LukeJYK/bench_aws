export const non_interactive: string
export const tooltip_content: string
export const left: string
export const tooltip_arrow: string
export const right: string
export const above: string
export const below: string
export const tooltip_row_label: string
export const tooltip_row_value: string
export const tooltip_color_block: string
export const close: string
export default ""
