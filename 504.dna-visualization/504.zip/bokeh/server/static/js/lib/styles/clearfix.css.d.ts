export const clearfix: string
export default ""
