export const input: string
export const toggle: string
export const visible: string
export default ""
