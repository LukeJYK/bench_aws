export const data_table: string
export const cell_special_defaults: string
export const cell_select: string
export const cell_index: string
export const header_index: string
export const cell_editor: string
export const cell_editor_completion: string
export default ""
