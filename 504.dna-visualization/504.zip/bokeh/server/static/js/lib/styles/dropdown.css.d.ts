export const menu: string
export const above: string
export const below: string
export const divider: string
export const active: string
export default ""
