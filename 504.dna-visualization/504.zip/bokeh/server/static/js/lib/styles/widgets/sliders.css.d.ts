export const slider_title: string
export const slider_value: string
export default ""
