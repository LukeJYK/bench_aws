export const caret: string
export const down: string
export const up: string
export const left: string
export const right: string
export default ""
