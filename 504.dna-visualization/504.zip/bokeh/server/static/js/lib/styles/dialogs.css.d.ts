export const title: string
export const content: string
export const buttons: string
export const close: string
export default ""
