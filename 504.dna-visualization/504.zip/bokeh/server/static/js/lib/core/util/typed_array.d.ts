import type { TypedArray } from "../types";
export declare function concat<T extends TypedArray>(array0: T, ...arrays: ArrayLike<number>[]): T;
//# sourceMappingURL=typed_array.d.ts.map