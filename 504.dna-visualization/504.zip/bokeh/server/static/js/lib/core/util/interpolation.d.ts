import type { FloatArray } from "../types";
export declare function catmullrom_spline(x: FloatArray, y: FloatArray, T?: number, tension?: number, closed?: boolean): [FloatArray, FloatArray];
//# sourceMappingURL=interpolation.d.ts.map