/** T is of import("some/module/path") type */
export declare function load_module<T>(module: Promise<T>): Promise<T | null>;
//# sourceMappingURL=modules.d.ts.map