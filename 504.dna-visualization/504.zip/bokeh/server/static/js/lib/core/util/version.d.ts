export declare function pyify_version(version: string): string;
//# sourceMappingURL=version.d.ts.map