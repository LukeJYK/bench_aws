import type { Document } from "../document";
import type { View } from "../core/view";
import { ViewManager } from "../core/view";
import type { EmbedTarget } from "./dom";
export declare const index: {
    [key: string]: View;
};
export declare function add_document_standalone(document: Document, element: EmbedTarget, roots?: (EmbedTarget | null)[], use_for_title?: boolean): Promise<ViewManager>;
//# sourceMappingURL=standalone.d.ts.map