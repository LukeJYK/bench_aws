import type { ViewManager } from "../core/view";
import type { EmbedTarget } from "./dom";
export declare function add_document_from_session(websocket_url: string, token: string, element: EmbedTarget, roots?: EmbedTarget[], use_for_title?: boolean): Promise<ViewManager>;
//# sourceMappingURL=server.d.ts.map