export { ParkMillerLCG } from "./park_miller_lcg";
//# sourceMappingURL=index.d.ts.map