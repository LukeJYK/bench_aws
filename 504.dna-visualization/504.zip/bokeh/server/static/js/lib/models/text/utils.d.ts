import type { BaseText } from "./base_text";
export declare function parse_delimited_string(text: string): BaseText;
//# sourceMappingURL=utils.d.ts.map