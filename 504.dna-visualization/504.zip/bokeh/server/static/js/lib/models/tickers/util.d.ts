export declare const ONE_MILLI = 1;
export declare const ONE_SECOND = 1000;
export declare const ONE_MINUTE: number;
export declare const ONE_HOUR: number;
export declare const ONE_DAY: number;
export declare const ONE_MONTH: number;
export declare const ONE_YEAR: number;
export declare function copy_date(date: Date): Date;
export declare function last_month_no_later_than(date: Date): Date;
export declare function last_year_no_later_than(date: Date): Date;
//# sourceMappingURL=util.d.ts.map