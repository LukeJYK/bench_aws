import type { Context2d } from "../../core/util/canvas";
import type { BBox, Corners } from "../../core/util/bbox";
export declare function round_rect(ctx: Context2d, bbox: BBox, border_radius: Corners<number>): void;
//# sourceMappingURL=painting.d.ts.map