export declare function tex2svg(formula: string, options?: MathJax.ConvertOptions, macros?: MathJax.TeXMacros): HTMLElement;
export declare function ascii2svg(_formula: string): HTMLElement;
export declare function mathml2svg(formula: string): HTMLElement;
export declare function find_tex(text: string): MathJax.ProtoItem[];
//# sourceMappingURL=index.d.ts.map