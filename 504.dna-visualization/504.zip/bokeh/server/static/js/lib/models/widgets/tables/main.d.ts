import * as Tables from "./index";
export { Tables };
//# sourceMappingURL=main.d.ts.map