export declare const version: string;
