export declare function safely<T>(fn: () => T, silent?: boolean): T | undefined;
//# sourceMappingURL=safely.d.ts.map